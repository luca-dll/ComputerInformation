﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace Computer_Information
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("CPU:");
            GetComponent("Win32_Processor", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("GPU:");
            GetComponent("Win32_VideoController", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Fan:");
            GetComponent("Win32_Fan", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Heat Pipe Cooling Device:");
            GetComponent("Win32_HeatPipe", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Refrigeration Device:");
            GetComponent("Win32_Refrigeration", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("BIOS:");
            GetComponent("Win32_BIOS", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Keyboard:");
            GetComponent("Win32_Keyboard", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Mouse:");
            GetComponent("Win32_PointingDevice", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Temperature Sensor:");
            GetComponent("Win32_TemperatureProbe", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Disk Drive:");
            GetComponent("Win32_DiskDrive", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Physical Media:");
            GetComponent("Win32_PhysicalMedia", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Motherboard:");
            GetComponent("Win32_BaseBoard", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Cache Memory:");
            GetComponent("Win32_CacheMemory", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Physical Memory:");
            GetComponent("Win32_PhysicalMemory", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Network Adapter:");
            GetComponent("Win32_NetworkAdapter", "Name");
            Console.WriteLine("----------------------------------------------------");
            Console.WriteLine("Monitor:");
            GetComponent("Win32_DesktopMonitor", "Name");
            Console.WriteLine("----------------------------------------------------");


            string machname = Environment.MachineName;
            string username = Environment.UserName;
            int procount = Environment.ProcessorCount;
            bool is64 = Environment.Is64BitOperatingSystem;
            string osver = Environment.OSVersion.ToString();
            string osplat = Environment.OSVersion.Platform.ToString();
            Console.WriteLine($"The machine name is : {machname}");
            Console.WriteLine($"The username is : {username}");
            Console.WriteLine($"It has {procount} cores");
            Console.WriteLine($"Is this program 64 bit? {is64}");
            Console.WriteLine($"The OS version is : {osver}");
            Console.WriteLine($"The OS platform is : {osplat}");
            Console.Read();
           


        }

        private static void GetComponent(string hwclass, string syntax)
        {
            ManagementObjectSearcher mos = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM " + hwclass);
            foreach (ManagementObject mj in mos.Get())
            {
                Console.WriteLine(Convert.ToString(mj[syntax]));
            }
        }
    }
}
